---
layout: list
title: Projects
permalink: /projects/
description: Selected works in AI Ethics & Digital Transformation.
menu: false
style: newspaper
---

Here you will find my selected projects regarding **Algorithmic Risk Assessment**, **Data Governance Frameworks**, and **Digital Transformation Strategies**.

*(This section is currently being updated with case studies and the AI Ethics Playbook.)*
